class Employee:
    @staticmethod
    def get_fired():
        return "fired..."
